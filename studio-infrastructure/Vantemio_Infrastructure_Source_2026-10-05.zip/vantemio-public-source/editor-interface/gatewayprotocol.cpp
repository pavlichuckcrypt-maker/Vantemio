#include "gatewayprotocol.h"

#include <QJsonDocument>
#include <QJsonParseError>

namespace KdenliveGateway
{

GatewayRequest GatewayProtocol::parseRequest(const QString &payloadJson)
{
    GatewayRequest request;
    QJsonParseError parseError;
    const QJsonDocument document = QJsonDocument::fromJson(payloadJson.toUtf8(), &parseError);
    if (parseError.error != QJsonParseError::NoError || !document.isObject()) {
        request.action = QStringLiteral("invalid_request");
        request.raw = QJsonObject{
            {QStringLiteral("parse_error"), parseError.errorString()},
            {QStringLiteral("payload_json"), payloadJson},
        };
        return request;
    }

    request.raw = document.object();
    request.action = request.raw.value(QStringLiteral("action")).toString().trimmed();
    request.requestId = request.raw.value(QStringLiteral("request_id")).toString().trimmed();
    request.projectId = request.raw.value(QStringLiteral("project_id")).toString().trimmed();
    request.params = request.raw.value(QStringLiteral("params")).toObject();
    return request;
}

QString GatewayProtocol::successResponse(
    const QString &action,
    const QString &requestId,
    const QString &projectId,
    int timelineRevision,
    const QJsonObject &result,
    const QStringList &warnings
)
{
    const QJsonObject payload{
        {QStringLiteral("status"), QStringLiteral("ok")},
        {QStringLiteral("action"), action},
        {QStringLiteral("request_id"), requestId},
        {QStringLiteral("project_id"), projectId},
        {QStringLiteral("timeline_revision"), timelineRevision},
        {QStringLiteral("result"), result},
        {QStringLiteral("warnings"), toJsonArray(warnings)},
        {QStringLiteral("errors"), QJsonArray{}},
    };
    return QString::fromUtf8(QJsonDocument(payload).toJson(QJsonDocument::Compact));
}

QString GatewayProtocol::errorResponse(
    const QString &action,
    const QString &requestId,
    const QString &projectId,
    int timelineRevision,
    const QString &errorCode,
    const QString &message,
    const QStringList &warnings
)
{
    const QJsonObject errorObject{
        {QStringLiteral("code"), errorCode},
        {QStringLiteral("message"), message},
    };
    const QJsonObject payload{
        {QStringLiteral("status"), QStringLiteral("error")},
        {QStringLiteral("action"), action},
        {QStringLiteral("request_id"), requestId},
        {QStringLiteral("project_id"), projectId},
        {QStringLiteral("timeline_revision"), timelineRevision},
        {QStringLiteral("result"), QJsonObject{}},
        {QStringLiteral("warnings"), toJsonArray(warnings)},
        {QStringLiteral("errors"), QJsonArray{errorObject}},
    };
    return QString::fromUtf8(QJsonDocument(payload).toJson(QJsonDocument::Compact));
}

QJsonArray GatewayProtocol::toJsonArray(const QStringList &items)
{
    QJsonArray array;
    for (const QString &item : items) {
        array.push_back(item);
    }
    return array;
}

} // namespace KdenliveGateway
