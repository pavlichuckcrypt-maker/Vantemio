#pragma once

#include <QJsonArray>
#include <QJsonObject>
#include <QString>
#include <QStringList>

namespace KdenliveGateway
{

struct GatewayRequest
{
    QString action;
    QString requestId;
    QString projectId;
    QJsonObject params;
    QJsonObject raw;
};

class GatewayProtocol
{
public:
    static GatewayRequest parseRequest(const QString &payloadJson);
    static QString successResponse(
        const QString &action,
        const QString &requestId,
        const QString &projectId,
        int timelineRevision,
        const QJsonObject &result = {},
        const QStringList &warnings = {}
    );
    static QString errorResponse(
        const QString &action,
        const QString &requestId,
        const QString &projectId,
        int timelineRevision,
        const QString &errorCode,
        const QString &message,
        const QStringList &warnings = {}
    );
    static QJsonArray toJsonArray(const QStringList &items);
};

} // namespace KdenliveGateway
