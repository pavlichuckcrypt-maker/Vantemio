"""Selected storage primitives. No production policy or existing memory data."""
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import sqlite3
import time

def encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)

def digest(value):
    return hashlib.sha256(encoded(value).encode('utf-8')).hexdigest()

class Memory:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connection() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS memory_events (
                    seq INTEGER PRIMARY KEY AUTOINCREMENT,
                    id TEXT NOT NULL UNIQUE, project TEXT NOT NULL,
                    stage TEXT NOT NULL, phase TEXT NOT NULL,
                    fingerprint TEXT NOT NULL, body TEXT NOT NULL,
                    recorded_at REAL NOT NULL);
                CREATE INDEX IF NOT EXISTS memory_stage
                    ON memory_events(project, stage, seq);
                CREATE TABLE IF NOT EXISTS memory_registry (
                    id TEXT PRIMARY KEY, kind TEXT NOT NULL, name TEXT NOT NULL,
                    body TEXT NOT NULL, recorded_at REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS memory_edges (
                    source TEXT NOT NULL, relation TEXT NOT NULL, target TEXT NOT NULL,
                    PRIMARY KEY(source, relation, target));
            ''')
            # Accidental UPDATE/DELETE must not erase a historical observation.
            for table in ('memory_events', 'memory_registry', 'memory_edges'):
                for operation in ('UPDATE', 'DELETE'):
                    db.execute(f'''CREATE TRIGGER IF NOT EXISTS {table}_{operation.lower()}
                        BEFORE {operation} ON {table}
                        BEGIN SELECT RAISE(ABORT, 'studio memory is append-only'); END''')

    @contextmanager
    def connection(self):
        db = sqlite3.connect(self.path, timeout=10)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA synchronous=FULL')
        try:
            with db:
                yield db
        finally:
            db.close()

    @staticmethod
    def _register(db, kind, name, body):
        revision = digest({'kind': kind, 'name': name, 'body': body})
        db.execute('INSERT OR IGNORE INTO memory_registry VALUES (?, ?, ?, ?, ?)',
                   (revision, kind, name, encoded(body), time.time()))
        return revision

    def register(self, kind, name, body):
        """Register a version, retaining all previous versions under the same name."""
        if not kind or not name or not isinstance(body, dict):
            raise ValueError('registry requires kind, name and object body')
        with self.connection() as db:
            return self._register(db, kind, name, body)

    def observe(self, project, stage, result, *, phase='result', inputs=None,
                code=None, dependencies=(), source=None):
        """Append a state transition. Repeated unchanged polling is idempotent.

        A -> B -> A is three observations; A -> A is one. Input/code changes
        produce new observations. Missing provenance remains explicitly missing.
        """
        if phase not in ('start', 'result', 'snapshot'):
            raise ValueError('invalid observation phase')
        if not stage or not isinstance(result, dict) or not isinstance(result.get('status'), str):
            raise ValueError('stage and status are required')
        project = str(Path(project).resolve())
        # Only controller timestamps are volatile; retain nested provider evidence.
        result = {k: v for k, v in result.items()
                  if k not in ('started_at', 'updated_at', 'memory')}
        body = {'schema': 'aim.studio.observation/v1', 'project': project,
                'stage': stage, 'phase': phase, 'result': result,
                'inputs': inputs or {}, 'code': code or {},
                'dependencies': sorted(set(dependencies)), 'source': source,
                'quality_approval': False}
        fingerprint = digest(body)
        with self.connection() as db:
            db.execute('BEGIN IMMEDIATE')
            previous = db.execute('''SELECT id, fingerprint FROM memory_events
                WHERE project=? AND stage=? AND phase=? ORDER BY seq DESC LIMIT 1''',
                (project, stage, phase)).fetchone()
            if previous and previous['fingerprint'] == fingerprint:
                return previous['id']
            event_id = digest({'body': body, 'previous': previous['id'] if previous else None})
            project_id = self._register(db, 'project', project, {'path': project})
            stage_id = self._register(db, 'stage', stage, {'project': project, 'stage': stage})
            edges = [(stage_id, 'belongs_to', project_id), (event_id, 'observes', stage_id)]
            if previous:
                edges.append((event_id, 'follows', previous['id']))
            for dependency in body['dependencies']:
                dep_id = self._register(db, 'stage', dependency, {'project': project, 'stage': dependency})
                edges.append((event_id, 'depends_on', dep_id))
            for kind, values in (('input_manifest', body['inputs']), ('code_manifest', body['code'])):
                if values:
                    ref = self._register(db, kind, stage, values)
                    edges.append((event_id, 'uses', ref))
            db.execute('INSERT INTO memory_events(id,project,stage,phase,fingerprint,body,recorded_at) VALUES(?,?,?,?,?,?,?)',
                       (event_id, project, stage, phase, fingerprint, encoded(body), time.time()))
            db.executemany('INSERT OR IGNORE INTO memory_edges VALUES(?,?,?)', edges)
            return event_id

    def recall(self, project, stage, limit=5):
        """Bounded factual context, suitable for code or a local model's prompt."""
        if not 1 <= limit <= 100:
            raise ValueError('limit must be between 1 and 100')
        with self.connection() as db:
            rows = db.execute('''SELECT id, body, recorded_at FROM memory_events
                WHERE project=? AND stage=? AND phase IN ('result','snapshot')
                ORDER BY seq DESC LIMIT ?''', (str(Path(project).resolve()), stage, limit)).fetchall()
        return [{'id': row['id'], 'recorded_at': row['recorded_at'], **json.loads(row['body'])} for row in rows]

    def graph(self):
        with self.connection() as db:
            nodes = [dict(row) for row in db.execute('SELECT id,kind,name,body FROM memory_registry ORDER BY id')]
            nodes.extend({'id': row['id'], 'kind': 'observation', 'name': row['stage'], 'body': row['body']}
                         for row in db.execute('SELECT id,stage,body FROM memory_events ORDER BY seq'))
            edges = [dict(row) for row in db.execute('SELECT * FROM memory_edges ORDER BY source,relation,target')]
        for node in nodes:
            node['body'] = json.loads(node['body'])
        return {'schema': 'aim.studio.memory_graph/v1', 'nodes': nodes, 'edges': edges}
