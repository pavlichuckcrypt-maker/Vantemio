"""Read-only packet assembly excerpt with an injected transport callback.

Hash checks bind bytes to a request; they do not authenticate a remote peer.
No SSH commands, worker execution, queue changes or production paths are included.
"""
import base64
import hashlib
import json
import re
from .memory import digest

MAX_BYTES = 8 * 1024 * 1024
WIRE_CHUNK_BYTES = 64 * 1024
MAX_WIRE_BYTES = 128 * 1024
SHA256 = re.compile(r"[0-9a-f]{64}")

class OutcomeUnknown(RuntimeError):
    """Retain the request when the response cannot be verified."""


def exchange(request, *, runner, command=None):
    if command is not None:
        raise ValueError('deployment commands are excluded')
    return runner(request)


def response_packet(request, *, runner, command=None):
    if request.get('op') != 'response_chunk':
        raise ValueError('only response packet reads are allowed')
    return exchange(request, runner=runner, command=command)


def observed_packet(cache, request, sha, offset, command):
    if cache is not None:
        raise ValueError('production cache is excluded')
    return None


def observation_packet_path(cache, request, sha, offset, command):
    if cache is not None:
        raise ValueError('production cache is excluded')
    return None

def assembled_response(request, *, runner, command=None, observation_sha256=None, packet_cache=None):
    """Validate every byte and identity before handing a claim to execution."""
    if len(json.dumps(request,ensure_ascii=False).encode())>MAX_BYTES:
        raise ValueError('oversized original request')
    if packet_cache is not None and request.get('op') != 'cutover_observation':
        raise ValueError('packet cache is only for immutable archive observations')
    if observation_sha256 is not None:
        if request.get('op') != 'cutover_observation' or not SHA256.fullmatch(str(observation_sha256)):
            raise ValueError('pinned packet recovery requires an immutable observation SHA')
        answer=observed_packet(packet_cache,request,observation_sha256,0,command)
        if answer is None:
            answer=response_packet({'op':'response_chunk','queue':request['queue'],'request':request,
                'request_sha256':digest(request),'response_sha256':observation_sha256,'offset':0},
                runner=runner,command=command)
        if '_queue_rpc_wire' not in answer:raise OutcomeUnknown('pinned observation packet missing')
    else:
        answer=exchange(request,runner=runner,command=command)
        if not isinstance(answer, dict) or '_queue_rpc_wire' not in answer:
            raise OutcomeUnknown('unframed response excluded from public chunk validator')
    parts=[];offset=0;expected=None
    for _ in range((MAX_BYTES+WIRE_CHUNK_BYTES-1)//WIRE_CHUNK_BYTES):
        wire=answer.get('_queue_rpc_wire')
        if not isinstance(wire,dict) or wire.get('schema')!='aim.queue.rpc_chunks/v1':
            raise OutcomeUnknown('invalid chunk response')
        total=wire.get('bytes');sha=wire.get('response_sha256')
        if observation_sha256 is not None and sha!=observation_sha256:
            raise OutcomeUnknown('pinned observation response SHA changed')
        if (type(total) is not int or not 0<total<=MAX_BYTES or not SHA256.fullmatch(str(sha))
                or wire.get('request_sha256')!=digest(request)
                or type(wire.get('offset')) is not int or wire['offset']!=offset):
            raise OutcomeUnknown('chunk request or offset binding changed')
        binding=(total,sha)
        if expected is not None and binding!=expected:
            raise OutcomeUnknown('chunk response binding changed; original operation retained')
        expected=binding
        try:part=base64.b64decode(wire['data'],validate=True)
        except (ValueError,KeyError,TypeError) as exc:
            raise OutcomeUnknown('invalid chunk bytes') from exc
        if len(part)!=min(WIRE_CHUNK_BYTES,total-offset) or wire.get('next')!=offset+len(part):
            raise OutcomeUnknown('chunk length or next offset changed')
        cache_path=observation_packet_path(packet_cache,request,sha,offset,command)
        if cache_path is not None:
            raw_packet=json.dumps(answer,sort_keys=True,separators=(',',':')).encode()
            if len(raw_packet)>MAX_WIRE_BYTES:raise OutcomeUnknown('observation cache packet exceeds wire bound')
            raise ValueError('disk packet cache is excluded from this public excerpt')
        parts.append(part);offset+=len(part)
        if offset==total:
            raw=b''.join(parts)
            if hashlib.sha256(raw).hexdigest()!=sha:
                raise OutcomeUnknown('assembled response hash changed')
            try:value=json.loads(raw)
            except (ValueError,UnicodeError) as exc:raise OutcomeUnknown('invalid assembled response') from exc
            if not isinstance(value,dict):raise OutcomeUnknown('assembled response is not an object')
            return value
        answer=observed_packet(packet_cache,request,sha,offset,command)
        if answer is None:
            answer=response_packet({'op':'response_chunk','queue':request['queue'],'request':request,
                            'request_sha256':digest(request),'response_sha256':sha,'offset':offset},
                            runner=runner,command=command)
    raise OutcomeUnknown('response exceeds bounded chunk budget')
