"""Selected VidRa gateway reply parsing, using a caller-supplied socket.

This exposes the client parser, not the editor fork, bridge credentials or commands.
"""
import json
import math
import time

class VidRAGatewayError(RuntimeError):
    pass

class GatewayReplyReader:
    def __init__(self, sock, *, timeout_sec=15, max_frame_bytes=1024 * 1024):
        if not math.isfinite(timeout_sec) or timeout_sec <= 0:
            raise ValueError('timeout must be finite and positive')
        if type(max_frame_bytes) is not int or max_frame_bytes < 1:
            raise ValueError('frame bound must be a positive integer')
        self.sock = sock
        self.timeout_sec = float(timeout_sec)
        self.max_frame_bytes = max_frame_bytes
        self._recv_buffer = bytearray()
        self.events = []
        self._event_bytes = 0

    def _read_reply(self, request_id, deadline):
        while True:
            line = self._readline(deadline)
            if not line:
                return line
            value = json.loads(line)
            if not isinstance(value, dict):
                raise VidRAGatewayError("gateway_response_not_object")
            if "bad_token" in (value.get("errors") or []):
                return line  # Preserve the existing authentication error explanation.
            if (value.get("request_id") == request_id and value.get("status") in ("ok", "error")
                    and value.get("kind") != "event"):
                return line
            size = len(line.encode("utf-8"))
            if self._event_bytes + size > self.max_frame_bytes or len(self.events) >= 4096:
                raise VidRAGatewayError("unsolicited_gateway_message_limit; drain_events required")
            self.events.append(value)
            self._event_bytes += size

    def _readline(self, deadline=None) -> str:
        deadline = time.monotonic() + self.timeout_sec if deadline is None else deadline
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise VidRAGatewayError("gateway_call_deadline")
            newline = self._recv_buffer.find(b"\n")
            if newline >= 0:
                if newline > self.max_frame_bytes:
                    raise VidRAGatewayError("gateway_frame_too_large")
                raw = bytes(self._recv_buffer[:newline])
                del self._recv_buffer[:newline + 1]
                return raw.decode("utf-8", errors="strict")
            if len(self._recv_buffer) > self.max_frame_bytes:
                raise VidRAGatewayError("gateway_frame_too_large")
            self.sock.settimeout(remaining)
            chunk = self.sock.recv(65536)
            if not chunk:
                if self._recv_buffer:
                    raise VidRAGatewayError("truncated_gateway_frame")
                return ""
            self._recv_buffer.extend(chunk)
