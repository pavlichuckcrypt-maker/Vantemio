import base64
import hashlib
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from vantemio_infrastructure.memory import Memory, encoded, digest
from vantemio_infrastructure.wire import assembled_response, OutcomeUnknown, WIRE_CHUNK_BYTES
from vantemio_infrastructure.vidra_reply import GatewayReplyReader, VidRAGatewayError

class MemoryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.project = str(Path(self.tmp.name) / 'synthetic-project')
        self.memory = Memory(Path(self.tmp.name) / 'test.sqlite')
    def observe(self, status='ready', **kwargs):
        return self.memory.observe(self.project, 'test-stage', {'status': status}, **kwargs)
    def test_polling_does_not_duplicate_history(self):
        self.assertEqual(self.observe(), self.observe())
        self.assertEqual(len(self.memory.recall(self.project, 'test-stage')), 1)
    def test_return_to_prior_state_preserves_transition(self):
        a=self.observe(); b=self.observe('failed'); c=self.observe()
        self.assertEqual(len({a,b,c}),3)
        self.assertEqual(len(self.memory.recall(self.project,'test-stage')),3)
    def test_changed_inputs_create_a_new_observation(self):
        self.assertNotEqual(self.observe(inputs={'version':1}),self.observe(inputs={'version':2}))
    def test_history_cannot_be_updated_or_deleted(self):
        self.observe()
        for sql in ['UPDATE memory_events SET stage="changed"','DELETE FROM memory_events']:
            with self.assertRaises(sqlite3.IntegrityError):
                with self.memory.connection() as db: db.execute(sql)
    def test_graph_preserves_dependencies_without_dangling_nodes(self):
        self.observe(dependencies=['input-stage'],inputs={'asset':'synthetic'})
        graph=self.memory.graph(); ids={n['id'] for n in graph['nodes']}
        self.assertTrue(any(e['relation']=='depends_on' for e in graph['edges']))
        self.assertTrue(all(e['source'] in ids and e['target'] in ids for e in graph['edges']))
    def test_registry_retains_previous_revisions(self):
        a=self.memory.register('test','synthetic',{'version':1})
        b=self.memory.register('test','synthetic',{'version':2})
        self.assertNotEqual(a,b); self.assertTrue({a,b} <= {n['id'] for n in self.memory.graph()['nodes']})
    def test_observation_is_not_a_quality_approval(self):
        self.observe(); self.assertFalse(self.memory.recall(self.project,'test-stage')[0]['quality_approval'])

class WireTests(unittest.TestCase):
    def setUp(self):
        self.request={'op':'synthetic_read','queue':'example','request_id':'example-request'}
        self.raw=encoded({'status':'example','data':'a'*(WIRE_CHUNK_BYTES+50)}).encode()
        self.response_hash=hashlib.sha256(self.raw).hexdigest()
    def runner(self, request):
        offset=request.get('offset',0);part=self.raw[offset:offset+WIRE_CHUNK_BYTES]
        return {'_queue_rpc_wire':{'schema':'aim.queue.rpc_chunks/v1','bytes':len(self.raw),
            'response_sha256':self.response_hash,'request_sha256':digest(self.request),
            'offset':offset,'next':offset+len(part),'data':base64.b64encode(part).decode()}}
    def test_exact_multipart_response_round_trip(self):
        self.assertEqual(assembled_response(self.request,runner=self.runner),json.loads(self.raw))
    def test_rejects_other_request_identity(self):
        def runner(r):
            p=self.runner(r);p['_queue_rpc_wire']['request_sha256']='0'*64;return p
        with self.assertRaises(OutcomeUnknown):assembled_response(self.request,runner=runner)
    def test_rejects_changed_offset(self):
        def runner(r):
            p=self.runner(r);p['_queue_rpc_wire']['offset']+=1;return p
        with self.assertRaises(OutcomeUnknown):assembled_response(self.request,runner=runner)
    def test_rejects_modified_bytes(self):
        def runner(r):
            p=self.runner(r);wire=p['_queue_rpc_wire'];raw=base64.b64decode(wire['data']);wire['data']=base64.b64encode(b'X'+raw[1:]).decode();return p
        with self.assertRaises(OutcomeUnknown):assembled_response(self.request,runner=runner)
    def test_rejects_changed_response_identity_between_chunks(self):
        def runner(r):
            p=self.runner(r)
            if r.get('offset',0):p['_queue_rpc_wire']['response_sha256']='0'*64
            return p
        with self.assertRaises(OutcomeUnknown):assembled_response(self.request,runner=runner)
    def test_rejects_unframed_response(self):
        with self.assertRaises(OutcomeUnknown):assembled_response(self.request,runner=lambda r:{'status':'ok'})

class FakeSocket:
    def __init__(self,chunks):self.chunks=list(chunks)
    def settimeout(self,value):pass
    def recv(self,size):return self.chunks.pop(0) if self.chunks else b''

class GatewayTests(unittest.TestCase):
    def reader(self,chunks,**kwargs):return GatewayReplyReader(FakeSocket(chunks),**kwargs)
    def test_split_frames_and_events_do_not_steal_the_matching_reply(self):
        event=encoded({'kind':'event','event':'example'}).encode()+b'\n'
        reply=encoded({'request_id':'example-request','status':'ok'}).encode()+b'\n'
        reader=self.reader([event+reply[:5],reply[5:]])
        self.assertEqual(json.loads(reader._read_reply('example-request',__import__('time').monotonic()+2))['status'],'ok')
        self.assertEqual(len(reader.events),1)
    def test_rejects_truncated_frame(self):
        with self.assertRaises(VidRAGatewayError):self.reader([b'{"status":'])._readline()
    def test_rejects_oversized_frame(self):
        with self.assertRaises(VidRAGatewayError):self.reader([b'x'*9+b'\n'],max_frame_bytes=8)._readline()
    def test_rejects_non_object_reply(self):
        with self.assertRaises(VidRAGatewayError):self.reader([b'[]\n'])._read_reply('example-request',__import__('time').monotonic()+2)

if __name__=='__main__':unittest.main()
